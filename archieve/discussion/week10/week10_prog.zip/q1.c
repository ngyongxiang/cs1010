// q1.c
#include <stdio.h>

int main(void) {
	char ch1 = '\062', ch2 = '\x41';

	printf("ch1 = %c; ch2 = %c\n", ch1, ch2);

	return 0;
}

